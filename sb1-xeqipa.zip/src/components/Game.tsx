import React, { useState, useEffect, useRef } from 'react';
import { collection, addDoc } from 'firebase/firestore';
import { useNavigate } from 'react-router-dom';
import { db } from '../firebase';
import { Play, Square, Send, XCircle } from 'lucide-react';

type GameState = 'initial' | 'playing' | 'stopped' | 'submitted';

export function Game() {
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [gameState, setGameState] = useState<GameState>('initial');
  const [startTime, setStartTime] = useState<number | null>(null);
  const [elapsedTime, setElapsedTime] = useState<number | null>(null);
  const [showTimer, setShowTimer] = useState(true);
  const [submitted, setSubmitted] = useState(false);
  const [countdown, setCountdown] = useState(10);
  const animationFrameRef = useRef<number>();

  useEffect(() => {
    if (gameState === 'playing') {
      setStartTime(Date.now());
      setCountdown(10);

      let startTimestamp = Date.now();

      const updateTimer = () => {
        const now = Date.now();
        const elapsed = (now - startTimestamp) / 1000;
        const remaining = Math.max(10 - elapsed, 0);
        setCountdown(remaining);

        if (remaining > 0 && gameState === 'playing') {
          animationFrameRef.current = requestAnimationFrame(updateTimer);
        }
      };

      animationFrameRef.current = requestAnimationFrame(updateTimer);

      const timerTimeout = setTimeout(() => {
        setShowTimer(false);
      }, 5000);

      return () => {
        if (animationFrameRef.current) {
          cancelAnimationFrame(animationFrameRef.current);
        }
        clearTimeout(timerTimeout);
      };
    }
  }, [gameState]);

  const handleStart = () => {
    if (!name) return;
    setGameState('playing');
    setShowTimer(true);
  };

  const handleStop = () => {
    if (gameState === 'playing') {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      const endTime = Date.now();
      const elapsed = (endTime - (startTime || 0)) / 1000;
      setElapsedTime(elapsed);
      setGameState('stopped');
    }
  };

  const handleSubmit = async () => {
    if (elapsedTime !== null) {
      try {
        setGameState('submitted');
        setSubmitted(true);

        await addDoc(collection(db, 'scores'), {
          name,
          time: elapsedTime,
          timestamp: new Date(),
        });

        navigate('/completion', { replace: true });
      } catch (error) {
        console.error('Error submitting score:', error);
        // Reset states if submission fails
        setGameState('stopped');
        setSubmitted(false);
      }
    }
  };

  const handleCancel = () => {
    setGameState('initial');
    setElapsedTime(null);
    setShowTimer(true);
    setCountdown(10);
  };

  // Prevent rendering if already submitted
  if (submitted) {
    return null;
  }

  if (gameState === 'initial') {
    return (
      <div className="max-w-md mx-auto mt-20 p-6 bg-white rounded-xl shadow-xl">
        <h1 className="text-2xl font-bold text-gray-800 mb-6">
          10秒チャレンジ
        </h1>
        <input
          type="text"
          placeholder="名前（フルネーム）を入力してください"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
        />
        <button
          onClick={handleStart}
          disabled={!name}
          className="mt-4 w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 disabled:opacity-50 flex items-center justify-center gap-2"
        >
          <Play className="w-5 h-5" />
          スタート
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto mt-20 p-6 bg-white rounded-xl shadow-xl">
      <h2 className="text-xl font-bold text-gray-800 mb-4">{name}さん</h2>

      {gameState === 'playing' && showTimer && (
        <div className="text-6xl font-bold text-center text-indigo-600 mb-6 font-mono">
          {countdown.toFixed(3)}
        </div>
      )}

      {gameState === 'playing' && (
        <button
          onClick={handleStop}
          className="w-full bg-red-600 text-white py-3 px-4 rounded-lg hover:bg-red-700 flex items-center justify-center gap-2"
        >
          <Square className="w-5 h-5" />
          ストップ
        </button>
      )}

      {gameState === 'stopped' && (
        <div className="space-y-4">
          <p className="text-2xl text-center font-bold text-gray-800">
            記録: {elapsedTime?.toFixed(3)}秒
          </p>
          <div className="flex gap-4">
            <button
              onClick={handleSubmit}
              className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 flex items-center justify-center gap-2"
            >
              <Send className="w-5 h-5" />
              送信
            </button>
            <button
              onClick={handleCancel}
              className="flex-1 bg-gray-600 text-white py-2 px-4 rounded-lg hover:bg-gray-700 flex items-center justify-center gap-2"
            >
              <XCircle className="w-5 h-5" />
              キャンセル
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default Game;
