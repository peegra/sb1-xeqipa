import React from 'react';
import { Trophy } from 'lucide-react';

export function Completion() {
  return (
    <div className="max-w-md mx-auto mt-20 p-8 bg-white rounded-xl shadow-xl text-center">
      <Trophy className="w-16 h-16 mx-auto mb-6 text-yellow-500" />
      <h1 className="text-3xl font-bold text-gray-800 mb-4">お疲れ様でした</h1>
    </div>
  );
}

export default Completion;