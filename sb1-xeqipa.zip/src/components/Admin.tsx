import React, { useEffect, useState } from 'react';
import { collection, query, orderBy, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { ClipboardList } from 'lucide-react';

interface Score {
  id: string;
  name: string;
  time: number;
  timestamp: Date;
}

export function Admin() {
  const [scores, setScores] = useState<Score[]>([]);

  useEffect(() => {
    const q = query(collection(db, 'scores'), orderBy('timestamp', 'desc'));

    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const scoreData: Score[] = [];
      querySnapshot.forEach((doc) => {
        scoreData.push({ id: doc.id, ...doc.data() } as Score);
      });

      // 10秒に一番近い順にソート
      scoreData.sort((a, b) => Math.abs(a.time - 10) - Math.abs(b.time - 10));

      // ソート済みのデータを状態に設定
      setScores(scoreData);
    });

    return () => unsubscribe();
  }, []);

  return (
    <div className="max-w-4xl mx-auto mt-8 p-6 bg-white rounded-xl shadow-xl">
      <div className="flex items-center gap-3 mb-6">
        <ClipboardList className="w-8 h-8 text-indigo-600" />
        <h1 className="text-2xl font-bold text-gray-800">管理画面</h1>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                ランキング
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                名前
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                時間
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                日時
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {scores.map((score, index) => (
              <tr key={score.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {index + 1}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {score.name}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {score.time.toFixed(3)}秒
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {new Date(score.timestamp).toLocaleString('ja-JP')}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Admin;
