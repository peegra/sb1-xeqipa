import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import { Game } from './components/Game';
import { Admin } from './components/Admin';
import { Completion } from './components/Completion';
import { Timer, ClipboardList } from 'lucide-react';

export function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-gradient-to-br from-indigo-500 to-purple-600">
        <nav className="bg-white/10 backdrop-blur-md border-b border-white/20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <Link to="/" className="flex items-center text-white hover:text-white/90 transition">
                <Timer className="w-8 h-8" />
                <span className="ml-2 text-xl font-bold">10秒チャレンジ</span>
              </Link>
              
              <Link 
                to="/admin" 
                className="flex items-center px-4 py-2 rounded-lg bg-white/20 text-white hover:bg-white/30 transition"
              >
                <ClipboardList className="w-5 h-5 mr-2" />
                管理画面
              </Link>
            </div>
          </div>
        </nav>
        
        <Routes>
          <Route path="/" element={<Game />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/completion" element={<Completion />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;